//Carson Walker
//This is my own work
import java.util.Scanner;

public class MonthDaysTest {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter month (1-12): ");
        int month = input.nextInt();

        System.out.print("Enter year: ");
        int year = input.nextInt();

        MonthDays monthDays = new MonthDays(month, year);
        int days = monthDays.getDays();

        System.out.printf("Number of days in %s, %d is %d.%n",
                monthName(month), year, days);
    }

    public static String monthName(int month) {
        String[] monthNames = {"January", "February", "March", "April", "May",
                "June", "July", "August", "September", "October", "November", "December"};
        return monthNames[month-1];
    }
}
