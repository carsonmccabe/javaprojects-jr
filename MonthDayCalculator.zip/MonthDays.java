//Carson Walker
//This is my own work
public class MonthDays {
    private int month;
    private int year;

    public MonthDays(int month, int year) {
        this.month = month;
        this.year = year;
    }

    public int getDays() {
        switch(month) {
            case 2:
                if(isLeapYear())
                    return 29;
                else
                    return 28;
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
            default:
                return 31;
        }
    }

    public boolean isLeapYear() {
        if(year % 4 != 0)
            return false;
        else if(year % 100 != 0)
            return true;
        else if(year % 400 != 0)
            return false;
        else
            return true;
    }
}
