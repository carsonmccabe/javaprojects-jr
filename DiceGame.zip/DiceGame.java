//Carson Walker
//This is my own work
import java.util.Scanner;

public class DiceGame {
    public static void main(String[] args) {
        Die computerDie = new Die(6);
        Die userDie = new Die(6);
        int computerWins = 0;
        int userWins = 0;

        for (int i = 0; i < 10; i++) {
            computerDie.roll();
            userDie.roll();

            if (computerDie.getValue() > userDie.getValue()) {
                computerWins++;
                System.out.println("Round " + (i+1) + ": Computer wins! (" + computerDie.getValue() + " vs " + userDie.getValue() + ")");
            } else if (userDie.getValue() > computerDie.getValue()) {
                userWins++;
                System.out.println("Round " + (i+1) + ": User wins! (" + userDie.getValue() + " vs " + computerDie.getValue() + ")");
            } else {
                System.out.println("Round " + (i+1) + ": Tie! (" + computerDie.getValue() + " vs " + userDie.getValue() + ")");
            }
        }

        System.out.println("\nFinal score:");
        System.out.println("Computer wins: " + computerWins);
        System.out.println("User wins: " + userWins);

        if (computerWins > userWins) {
            System.out.println("The computer wins!");
        } else if (userWins > computerWins) {
            System.out.println("The user wins!");
        } else {
            System.out.println("It's a tie!");
        }
    }
}
