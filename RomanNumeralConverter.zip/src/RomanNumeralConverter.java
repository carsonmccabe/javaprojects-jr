import java.util.Scanner;

public class RomanNumeralConverter {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a number between 1 and 10: ");
        int number = input.nextInt();

        if (number < 1 || number > 10) {
            System.out.println("Error: Number must be between 1 and 10.");
        } else {
            String romanNumeral = convertToRomanNumeral(number);
            System.out.printf("%d is %s in Roman numerals.%n", number, romanNumeral);
        }
    }

    public static String convertToRomanNumeral(int number) {
        String[] romanNumeralLookup = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return romanNumeralLookup[number];
    }
}
