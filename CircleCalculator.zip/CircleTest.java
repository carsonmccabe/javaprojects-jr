//Carson Walker
//This is my own work
import java.util.Scanner;

public class CircleTest {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the radius of the circle: ");
        double r = input.nextDouble();

        Circle c = new Circle(r);

        System.out.println("The area is: " + c.getArea());
        System.out.println("The diameter is: " + c.getDiameter());
        System.out.println("The circumference is: " + c.getCircumference());

    }
}
