import java.util.Scanner;

public class SalaryCalculator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int daysWorked;

        do {
            System.out.print("Enter the number of days worked: ");
            daysWorked = input.nextInt();
        } while (daysWorked < 1);

        double salary = 0.01;
        System.out.println("Day\tSalary");
        for (int day = 1; day <= daysWorked; day++) {
            System.out.printf("%d\t$%.2f%n", day, salary);
            salary *= 2;
        }

        double totalPay = salary / 2;
        System.out.printf("Total pay over %d days: $%.2f%n", daysWorked, totalPay);
    }
}
